

<?php $__env->startSection('content'); ?>
    <div class="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <h2 class="text-2xl font-semibold text-gray-800 mb-6"> Admin Dashboard 
               <a href="<?php echo e(route('leads.index')); ?>" class="bg-blue-600 text-white px-1 py-2 rounded">
      view Leads
           </a>

</h2>

        <!-- Total Leads -->
        <div class="bg-white shadow rounded-lg p-6 mb-6">
            <h3 class="text-lg font-medium text-gray-700 mb-2">Total Leads</h3>
            <p class="text-3xl font-bold text-blue-600"><?php echo e($totalLeads); ?></p>
        </div>

        <!-- Leads by Status -->
        <div class="bg-white shadow rounded-lg p-6">
            <h3 class="text-lg font-medium text-gray-700 mb-4">Leads by Status</h3>
            <ul class="space-y-3">
                <?php $__empty_1 = true; $__currentLoopData = $leadsByStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="flex items-center justify-between border-b pb-2">
                        <span class="text-gray-600 font-semibold"><?php echo e($item->status); ?></span>
                        <span class="text-gray-800 text-lg font-bold"><?php echo e($item->total); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="text-gray-500">No data available.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leads-management\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>
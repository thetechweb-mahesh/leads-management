

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Lead Details</h1>     

    <div class="card mb-3">
        <div class="card-body">
            <h5 class="card-title"><?php echo e($lead->name); ?></h5>
            <p class="card-text"><strong>Status:</strong> <?php echo e($lead->status); ?></p>
            <p class="card-text"><strong>Remarks:</strong> <?php echo e($lead->remarks); ?></p>
            <?php if($lead->assignedTo): ?>
                <p class="card-text">
                    <strong>Assigned To:</strong> <?php echo e($lead->assignedTo->name); ?> (<?php echo e($lead->assignedTo->role); ?>)
                </p>
            <?php else: ?>
                <p class="card-text"><strong>Assigned To:</strong> Unassigned</p>
            <?php endif; ?>
            <p class="card-text"><small class="text-muted">Created: <?php echo e($lead->created_at->format('Y-m-d')); ?></small></p>
        </div>
    </div>

    <hr>
    <a href="<?php echo e(route('leads.index')); ?>" class="btn btn-secondary bg-blue-600 text-white px-4 py-2 rounded">Back to Leads</a>
    <a href="<?php echo e(route('leads.edit', $lead)); ?>" class="btn btn-primary">Edit Lead</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leads-management\resources\views/leads/show.blade.php ENDPATH**/ ?>
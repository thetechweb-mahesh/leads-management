

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto py-6">
    <h1 class="text-2xl font-bold mb-4">Leads <a href="<?php echo e(route('dashboard')); ?>" class="text-blue px-4 py-2 rounded">Back to dashboard</a></h1> 

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-2 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>


    <form method="GET" class="flex gap-4 mb-4">
        <select name="status" class="border rounded p-2">
            <option value="">All Statuses</option>
            <?php $__currentLoopData = ['New', 'Contacted', 'Converted', 'Lost']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($status); ?>" <?php echo e(request('status') === $status ? 'selected' : ''); ?>><?php echo e($status); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select name="lead_source" class="border rounded p-2">
            <option value="">All Sources</option>
            <?php $__currentLoopData = $leads->pluck('lead_source')->unique(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($source); ?>" <?php echo e(request('lead_source') === $source ? 'selected' : ''); ?>><?php echo e($source); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Filter</button>

    </form>


<?php if(auth()->user()?->role === 'admin'): ?>
    <a href="<?php echo e(route('leads.export')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded">
        Download CSV
    </a>

    <a href="<?php echo e(route('leads.create')); ?>" class="bg-green-600 text-white px-4 py-2 rounded">
        + Create Lead
    </a>
<?php endif; ?>






    <div class="overflow-x-auto bg-white shadow rounded">
        <table class="min-w-full">
            <thead>
                <tr class="bg-gray-100 text-left text-sm font-medium">
                    <th class="p-2">Name</th>
                    <th class="p-2">Email</th>
                    <th class="p-2">Phone</th>
                    <th class="p-2">Status</th>
                    <th class="p-2">Source</th>
                    <th class="p-2">Assigned</th>
                    <th class="p-2">Actions</th>
                </tr>
            </thead>
            <tbody class="text-sm">
                <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="p-2"><?php echo e($lead->name); ?></td>
                        <td class="p-2"><?php echo e($lead->email); ?></td>
                        <td class="p-2"><?php echo e($lead->phone); ?></td>
                        <td class="p-2"><?php echo e($lead->status); ?></td>
                        <td class="p-2"><?php echo e($lead->lead_source); ?></td>
                        <td class="p-2"><?php echo e(optional($lead->user)->name); ?></td>
                        <td class="p-2 flex gap-2">
                            <a href="<?php echo e(route('leads.show', $lead)); ?>" class="text-blue-600">View</a>   <?php if(auth()->user()->role === 'admin'): ?>
                            <a href="<?php echo e(route('leads.edit', $lead)); ?>" class="text-yellow-600">Edit</a>  <?php endif; ?>
                            <?php if(auth()->user()->role === 'admin'): ?>
                                <form action="<?php echo e(route('leads.destroy', $lead)); ?>" method="POST" onsubmit="return confirm('Delete this lead?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-600">Delete</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($leads->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leads-management\resources\views/leads/index.blade.php ENDPATH**/ ?>